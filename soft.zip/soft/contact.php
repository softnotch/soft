<?php
if(isset($_POST['send'])){
$name = $_POST['name'];
$email = $_POST['email'];
$body = $_POST['message'];
$subject = $_POST['subject'];

$result = 'We will get back to you in a jiffy';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Contact | Soft Learn</title>
    <meta charset="UTF-8">
    <meta name="description" content="WebUni Education Template">
    <meta name="keywords" content="webuni, education, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Favicon -->   
    <link href="img/favicon.ico" rel="shortcut icon"/>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,500,500i,600,600i,700,700i,800,800i" rel="stylesheet">

    <!-- Stylesheets -->
    <link rel="stylesheet" href="css/bootstrap.min.css"/>
    <link rel="stylesheet" href="css/font-awesome.min.css"/>
    <link rel="stylesheet" href="css/owl.carousel.css"/>
    <link rel="stylesheet" href="css/style.css"/>


    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body>
    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <!-- Header section -->
    <header class="header-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3">
                    <div class="site-logo">
                        <h2 style="font-family: 'Nunito' , sans-serif; color: white;">Soft Learn</h2>
                    </div>
                    <div class="nav-switch">
                        <i class="fa fa-bars"></i>
                    </div>
                </div>
                <div class="col-lg-9 col-md-9">
                    <a href="login.php" class="site-btn header-btn" style="-webkit-box-shadow: 9px 10px 30px -13px rgba(0,0,0,0.75);
-moz-box-shadow: 9px 10px 30px -13px rgba(0,0,0,0.75);
box-shadow: 9px 10px 30px -13px rgba(0,0,0,0.75);">Login</a>
                    <nav class="main-menu">
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li><a href="courses.html">Courses</a></li>
                            <li><a href="contact.php">Contact</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- Header section end -->


    <!-- Page info -->
    <div class="page-info-section set-bg" style="background:  #d63031;">
        <div class="container">
            <div class="site-breadcrumb">
                <a href="#">Home</a>
                <span style="color: white;">Contact</span>
            </div>
        </div>
    </div>
    <!-- Page info end -->





    <!-- Page -->
    <section class="contact-page spad pb-0">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="contact-form-warp">
                        <div class="section-title text-white text-left">
                            <h2>Get in Touch</h2>
                        </div>
                        <form class="contact-form" action="contact.php" method="post">
                            <p style="color: red; font-family: 'Quicksand', sans-serif; font-size:15px;"><?php echo $result; ?></p>
                            <input type="text" placeholder="Your Name" id="name" name="name">
                            <input type="text" placeholder="Your E-mail" id="email" name="email">
                            <input type="text" placeholder="Subject" id="subject" name="subject">
                            <textarea placeholder="Message" id="message" name="body"></textarea>
                            <button class="site-btn" name="send" type="submit">Send Message</button>
                        </form>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="contact-info-area">
                        <div class="section-title text-left p-0">
                            <h2>Contact Info</h2>
                        
                        </div>
                        <div class="phone-number">
                            <span>Direct Line</span>
                            <h2>+2348105279579</h2>
                        </div>
                        <ul class="contact-list">
                            <li>2 Ajayi Aina Street <br>Lagos, Nigeria</li>
                            <li>+2348026484107</li>
                            <li>softnotchacademy@gmail.com</li>
                        </ul>
                        <div class="social-links">
                                   <a href="https://web.facebook.com/Softnotch-Intergrated-2131664426882628/"><i class="fa fa-facebook"></i></a>
                <a href="https://www.instagram.com/softnotch/"><i class="fa fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <!-- Page end -->


    <!-- banner section -->
    <section class="banner-section spad">
        <div class="container">
            <div class="section-title mb-0 pb-2">
                <h2>Join Our Community Now!</h2>
                <p>Join Soft Learn today to either learn or teach today !!!.</p>
            </div>
            <div class="text-center pt-5">
                <a href="register.php" class="site-btn">Register Now</a>
            </div>
        </div>
    </section>
    <!-- banner section end -->


    <!-- footer section -->

        <div class="footer-bottom">
            <div class="footer-warp">           
                <div class="copyright"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>

        </div>
    </footer> 
    <!-- footer section end -->


    <!--====== Javascripts & Jquery ======-->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/mixitup.min.js"></script>
    <script src="js/circle-progress.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>


    <!-- load for map -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCWTIlluowDL-X4HbYQt3aDw_oi2JP0Krc&sensor=false"></script>
    <script src="js/map.js"></script>


    <script src="https://smtpjs.com/v3/smtp.js"></script>
    <script type="text/javascript">

    Email.send({
    Host : "smtp.gmail.com",
    Username : "softnotch2019@gmail.com",
    Password : "soft2019",
    To : "softnotch2019@gmail.com",
    From : "<?php echo $email; ?>",
    Subject : "<?php echo $subject; ?>",
    Body : "<?php echo $message; ?>"
}).then(
console.log(message)
);

    </script>
</body>
</html>