<?php
require  'conn.php';

$query  = "SELECT  id, email, state FROM payment WHERE pass = '{$_COOKIE['pass']}' ";

$result   = mysqli_query($conn, $query);

$emails =  mysqli_fetch_all($result, MYSQLI_ASSOC);

mysqli_free_result($result);

mysqli_close($conn);


?>
