<?php
require 'conn.php';

if(isset($_POST['continue'])){
 setcookie("testuser", $_POST['testuser'], time() +(5*24*60*60));
setcookie("testemail", $_POST['testemail'], time() +(5*24*60*60));
header('location:register.php');
}
if (isset($_POST['register'])) {

$target = "teacher-img/" .basename($_FILES['file']['name']);

$file = $_FILES['file']['name'];
$name = $_POST['name'];
$phone = $_POST['phone'];
$email  = $_POST['email'];
$account = $_POST['account'];


$sql = "INSERT INTO tutors (file, phone, name, email, account) VALUES ('$file', '$phone', '$name', '$email', '$account')";
$result = mysqli_query($conn,$sql);

if (move_uploaded_file($_FILES['file']['tmp_name'], $target)) {
  $update =  "Successful Registration Will be get back to you in the next 2days";
}else{
  $update =  "An internal error occured";
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Wakocoding | Home</title>
    <meta charset="UTF-8">
    <meta name="description" content="WebUni Education Template">
    <meta name="keywords" content="webuni, education, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Favicon -->   
    <link href="img/favicon.ico" rel="shortcut icon"/>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,500,500i,600,600i,700,700i,800,800i" rel="stylesheet">
    <!---Font Awesome--->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" type="text/css">


    <link rel="stylesheet" href="css/bootstrap.min.css"/>
    <link rel="stylesheet" href="css/font-awesome.min.css"/>
    <link rel="stylesheet" href="css/owl.carousel.css"/>
    <link rel="stylesheet" href="css/style.css"/>


    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body>
    <!-- Page Preloder -->
    <div class="container">
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <!-- Header section -->
    <header class="header-section">
        <div class="container">
            <div class="row " style="background-color:#fff;">
                <div class="col-lg-3 col-md-3" >
                    <div class="site-logo">
                    <img src="img/WAKKO22.png" height="43.34px !important" alt="">

                    </div>
                    <div class="nav-switch">
                        <i class="fa fa-bars"></i>
                    </div>
                </div>
                <div class="col-lg-9 col-md-9">
                    <a href="login.php" class="site-btn header-btn" style=" background-color:rgba(145,216,247,1); -webkit-box-shadow: 9px 10px 30px -13px rgba(0,0,0,0.75);
-moz-box-shadow: 9px 10px 30px -13px rgba(0,0,0,0.75);
box-shadow: 9px 10px 30px -13px rgba(0,0,0,0.75);">Login</a>
                    <nav class="main-menu" >
                        <ul>
                            <li><a href="http://localhost/learn/" style="color:rgba(145,216,247,1);">Home</a></li>
                            <li><a href="courses.html" style="color:rgba(145,216,247,1);">Tutorials</a></li>
                            <li><a href="contact.php"style="color:rgba(145,216,247,1);" >Contact</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- Header section end -->


    <!-- Hero section -->
    <section class="hero-section set-bg" style="background: #d63031;">
        <div class="container">
            <div class="hero-text text-white">
                <h2 style="font-family: 'Nunito', sans-serif; "><h1><span style="color:rgba(145,216,247,1);">Become</span> a 
  <span
     class="txt-rotate"
     data-period="2000"
     data-rotate='[ "Tech Entrepreneur.", "Software Developer.", "Tech Guru."]'></span>
</h1></h2>
                <p>Wakocoding is powered by SoftNotch</p>
            </div>
            <div class="row">
                <div class="col-lg-10 offset-lg-1">
                    <form class="intro-newslatter" action="index.php" method="post">
                        <input type="text" placeholder="Username" name="testuser">
                        <input type="text" class="last-s" placeholder="E-mail" name="testemail">
                        <button class="site-btn" name="continue" type="submit" style="background-color:rgba(145,216,247,1); -webkit-box-shadow: 9px 10px 30px -13px rgba(0,0,0,0.75);
-moz-box-shadow: 9px 10px 30px -13px rgba(0,0,0,0.75);
box-shadow: 9px 10px 30px -13px rgba(0,0,0,0.75);">Sign Up Now</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero section end -->


    <!-- categories section -->
    <section class="categories-section spad">
        <div class="container">
            <div class="section-title">
                <h2>Our Course Categories</h2>
                
            </div>
            <div class="row">
                <!-- categorie -->
                <div class="col-lg-4 col-md-6">
                    <div class="categorie-item">
                        <div class="ci-thumb set-bg" style="background: #ff6b6b">
                            
   <div class="price" style="background: #ff6b6b; width:6rem; padding: 0.5rem 0.5rem 0.5rem 0.5rem; color: white; box-shadow: 0 1rem 1rem 1rem rgba(0, 0, 0, 0.1); font-family: 'poppins', sans-serif; ">NGN 8000</div>
   <img src="img/dm.jpg">
</div>
                        <div class="ci-text">
                            <h5>Digital Marketing</h5>
                            <!--p>Session by Micheal King</p-->
                            <span></span>
                        </div>
                    </div>
                </div>

                        <div class="col-lg-4 col-md-6">
                    <div class="categorie-item">
                        <div class="ci-thumb set-bg" style="background: #1dd1a1;">
                                            <div class="price" style="background: #1dd1a1; width:6rem; padding: 0.5rem 0.5rem 0.5rem 0.5rem; color: white; box-shadow: 0 1rem 1rem 1rem rgba(0, 0, 0, 0.1); font-family: 'poppins', sans-serif; ">NGN 2000</div>
                                            <img src="img/wd.jpg">
                                        </div>
                        <div class="ci-text">
                            <h5>Git Tutorial</h5>
                            <!--p>Session by Famous</p-->
                            <span></span>
                        </div>
                    </div>
                </div>
                <!-- categorie -->
                <div class="col-lg-4 col-md-6">
                    <div class="categorie-item">
                        <div class="ci-thumb set-bg" style="background: #5f27cd;">
                        <div class="price"  style="background:#5f27cd; width:6rem; padding: 0.5rem 0.5rem 0.5rem 0.5rem; color: white; box-shadow: 0 1rem 1rem 1rem rgba(0, 0, 0, 0.1); font-family: 'poppins', sans-serif; ">NGN 5000</div>                  
                        <img src="img/jwd.jpg">
                    </div>
                        <div class="ci-text">
                            <h5>Introduction To Web Design</h5>
                            <!--p>Session By Kelvin</p-->
                            <span></span>
                        </div>
                    </div>
                </div>
                <!-- categorie -->
                <div class="col-lg-4 col-md-6">
                    <div class="categorie-item">
                        <div class="ci-thumb set-bg"style="background: #576574;" >
                        <div class="price" style="background:#576574; width:6rem; padding: 0.5rem 0.5rem 0.5rem 0.5rem; color: white; box-shadow: 0 1rem 1rem 1rem rgba(0, 0, 0, 0.1); font-family: 'poppins', sans-serif; ">NGN 6000</div>                  
                        <img src="img/lc.jpg">    
                    </div>
                        <div class="ci-text">
                            <h5>Hybrid App Development</h5>
                            <!--p>Session by Famous</p-->
                            <span></span>
                        </div>
                    </div>
                </div>
                    <div class="col-lg-4 col-md-6">
                    <div class="categorie-item">
                        <div class="ci-thumb set-bg" style="background: #ff7675;">
                                            <div class="price" style="background:#ff7675; width:6rem; padding: 0.5rem 0.5rem 0.5rem 0.5rem; color: white; box-shadow: 0 1rem 1rem 1rem rgba(0, 0, 0, 0.1); font-family: 'poppins', sans-serif; " >NGN 3000</div>
                                            <img src="img/cd.jpg">
                                        </div>
                        <div class="ci-text">
                            <h5>UI & UX Design</h5>
                            <!--p>Session by Melody</p-->
                            <span></span>
                        </div>
                    </div>
                </div>
                <!-- categorie -->
                <div class="col-lg-4 col-md-6">
                    <div class="categorie-item">
                        <div class="ci-thumb set-bg" style="background: #0984e3;">
                        <div class="price"   style="background:#0984e3; width:6rem; padding: 0.5rem 0.5rem 0.5rem 0.5rem; color: white; box-shadow: 0 1rem 1rem 1rem rgba(0, 0, 0, 0.1); font-family: 'poppins', sans-serif; ">NGN 8500</div>                  
                        <img src="img/py.jpg">    
                    </div>
                        <div class="ci-text">
                            <h5>Introduction to Python</h5>
                            <!--p>Session by Muritala David</p-->
                            <span></span>
                        </div>
                    </div>
                </div>
                <!-- categorie -->
                <div class="col-lg-4 col-md-6">
                    <div class="categorie-item">
                        <div class="ci-thumb set-bg"  style="background:#4834d4;">
                        <div class="price"  style="background:#4834d4; width:6rem; padding: 0.5rem 0.5rem 0.5rem 0.5rem; color: white; box-shadow: 0 1rem 1rem 1rem rgba(0, 0, 0, 0.1); font-family: 'poppins', sans-serif; ">NGN 3000</div>                  
                        <img src="img/dm.jpg">    
                    </div>
                        <div class="ci-text">
                            <h5>Database Management [MySQL] </h5>
                            <!--p>Session by Muritala David</p-->
                            <span></span>
                        </div>
                    </div>
                </div>
                <!-- categorie -->
                <div class="col-lg-4 col-md-6">
                    <div class="categorie-item">
                        <div class="ci-thumb set-bg"   style="background:#fdcb6e;">
                        
                        <div class="price"  style="background:#fdcb6e; width:6rem; padding: 0.5rem 0.5rem 0.5rem 0.5rem; color: white; box-shadow: 0 1rem 1rem 1rem rgba(0, 0, 0, 0.1); font-family: 'poppins', sans-serif; ">NGN 4000</div>                  
                        <img src="img/js.jpg">    
                    </div>
                        <div class="ci-text">
                            <h5>Introduction To JavaScript</h5>
                            <!--p>Session by Kelvin</p-->
                            <span></span>
                        </div>
                    </div>
                </div>

                                <div class="col-lg-4 col-md-6">
                    <div class="categorie-item">
                        <div class="ci-thumb set-bg"   style="background:#10ac84">
                        <div class="price"  style="background:#10ac84; width:6rem; padding: 0.5rem 0.5rem 0.5rem 0.5rem; color: white; box-shadow: 0 1rem 1rem 1rem rgba(0, 0, 0, 0.1); font-family: 'poppins', sans-serif; ">NGN 6000</div>                  
                        <img src="img/cd.jpg">    
                    </div>
                        <div class="ci-text">
                            <h5>Node Js</h5>
                            <!--p>Session by Kelvin</p-->
                            <span></span>
                        </div>
                    </div>
                </div>

                        <div class="col-lg-4 col-md-6">
                    <div class="categorie-item">
                        <div class="ci-thumb set-bg" style="background:#EE5A24;">
                                            <div class="price" style="background:#EE5A24; width:6rem; padding: 0.5rem 0.5rem 0.5rem 0.5rem; color: white; box-shadow: 0 1rem 1rem 1rem rgba(0, 0, 0, 0.1); font-family: 'poppins', sans-serif; ">NGN 5500</div>
                                            <img src="img/cd.jpg">
                                        </div>
                        <div class="ci-text">
                            <h5>Introduction To Java</h5>
                            <!--p>Session by John</p-->
                            <span></span>
                        </div>
                    </div>
                </div>
                  
            </div>
              <center>
                        <p href="#" style="font-size: 20px;">MORE</p>
                    </center>
        </div>


    </section>
    <!-- categories section end -->





    <!-- course section -->
    <section class="course-section spad">
        <div class="container">
            <div class="section-title mb-0">
                <h2>Tutorials</h2>
              <p>These tutorials are absolutely free</p>
            </div>
        </div>
        <div class="course-warp">
            <ul class="course-filter controls">
                <li class="control active" data-filter="all">All</li>
                <li class="control" data-filter=".finance">Web Design</li>
                <li class="control" data-filter=".design">Python</li>
                <li class="control" data-filter=".web">Web Development</li>
                <li class="control" data-filter=".photo">Hybrid Aplication Development</li>
            </ul>                                       
            <div class="row course-items-area">
                <!-- course -->
                <div class="mix col-lg-3 col-md-4 col-sm-6 finance">
                    <div class="course-item">
                        <div class="course-thumb set-bg" data-setbg="img/courses/first.jpg">
                            <div class="price">Free</div>
                        </div>
                        <div class="course-info">
                            <div class="course-text">
                                <h5 style="font-family: 'Nunito', sans-serif;">Html 5 & Css 3</h5>
                                <p style="font-family: 'Nunito', sans-serif;">Duration 3 hours</p>
                                <div class="students"></div>
                            </div>
                            <div class="course-author">
                            
                                <p>SoftNotch <span> Product</span></p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- course -->
                <div class="mix col-lg-3 col-md-4 col-sm-6 web">
                    <div class="course-item">
                        <div class="course-thumb set-bg" data-setbg="img/courses/cal.jpg">
                            <div class="price">Free</div>
                        </div>
                        <div class="course-info">
                            <div class="course-text">
                                <h5 style="font-family: 'Nunito', sans-serif;">Javascript Calculator </h5>
                                <!--p style="font-family: 'Nunito', sans-serif;">Lorem ipsum dolor sit amet, consectetur</p-->
                                <div class="students"></div>
                            </div>
                            <div class="course-author">
                            
                                <p>SoftNotch<span> Product</span></p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- course -->
                <div class="mix col-lg-3 col-md-4 col-sm-6 finance">
                    <div class="course-item">
                        <div class="course-thumb set-bg" data-setbg="img/courses/webdesign.jpg">
                            <div class="price">Free</div>
                        </div>
                        <div class="course-info">
                            <div class="course-text">
                                <h5 style="font-family: 'Nunito', sans-serif;">Build a website from scratch</h5>
                                <!--p style="font-family: 'Nunito', sans-serif;">Session by Muritala David</p-->
                                <div class="students"></div>
                            </div>
                            <div class="course-author">
                            
                                <p>SoftNotch<span> Product</span></p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- course -->
                <div class="mix col-lg-3 col-md-4 col-sm-6 web">
                    <div class="course-item">
                        <div class="course-thumb set-bg" data-setbg="img/courses/login.jpg">
                            <div class="price">Free</div>
                        </div>
                        <div class="course-info">
                            <div class="course-text">
                                <h5 style="font-family: 'Nunito', sans-serif;">PHP Login System</h5>
                                <!--p style="font-family: 'Nunito', sans-serif;">Session by Muritala David</p-->
                                <div class="students"></div>
                            </div>
                            <div class="course-author">
                    <p>SoftNotch<span> Product</span></p>
                            </div>
                        </div>
                    </div>
                </div>

                       <div class="mix col-lg-3 col-md-4 col-sm-6 web">
                    <div class="course-item">
                        <div class="course-thumb set-bg" data-setbg="img/courses/images.jpg">
                            <div class="price">Free</div>
                        </div>
                        <div class="course-info">
                            <div class="course-text">
                                <h5 style="font-family: 'Nunito', sans-serif;">Node Js Installation</h5>
                                <!--p style="font-family: 'Nunito', sans-serif;">Session by Kelvin</p-->
                                <div class="students"></div>
                            </div>
                            <div class="course-author">
                    <p>SoftNotch<span> Product</span></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- course -->
                <div class="mix col-lg-3 col-md-4 col-sm-6 web">
                    <div class="course-item">
                        <div class="course-thumb set-bg" data-setbg="img/courses/stopwatch.jpg">
                            <div class="price">Free</div>
                        </div>
                        <div class="course-info">
                            <div class="course-text">
                                <h5 style="font-family: 'Nunito', sans-serif;">Javascript Stop Watch </h5>
                                <!--p style="font-family: 'Nunito', sans-serif;">Lorem ipsum dolor sit amet, consectetur</p-->
                                <div class="students"></div>
                            </div>
                            <div class="course-author">
                                <div class="ca-pic set-bg" data-setbg="img/authors/footer.jpg"></div>

                            </div>
                        </div>
                    </div>
                </div>
                <!-- course -->
                <div class="mix col-lg-3 col-md-4 col-sm-6 finance">
                    <div class="course-item">
                        <div class="course-thumb set-bg" data-setbg="img/courses/footer.jpg">
                            <div class="price">Free</div>
                        </div>
                        <div class="course-info">
                            <div class="course-text">
                                <h5 style="font-family: 'Nunito', sans-serif;">Footer Design With Bootstrap</h5>
                                <!--p style="font-family: 'Nunito', sans-serif;">Lorem ipsum dolor sit amet, consectetur</p-->
                                <div class="students"></div>
                            </div>
                            <div class="course-author">

                                <p>SoftNotch<span> Product</span></p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- course -->
                <div class="mix col-lg-3 col-md-4 col-sm-6 web">
                    <div class="course-item">
                        <div class="course-thumb set-bg" data-setbg="img/courses/database.jpg">
                            <div class="price">Free</div>
                        </div>
                        <div class="course-info">
                            <div class="course-text">
                                <h5 style="font-family: 'Nunito', sans-serif;">MySQL Data Manipulation</h5>
                                <!--p style="font-family: 'Nunito', sans-serif;">Lorem ipsum dolor sit amet, consectetur</p-->
                                <div class="students"></div>
                            </div>
                            <div class="course-author">
                        
                                <p>SoftNotch<span> Product</span></p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- course -->
                <div class="mix col-lg-3 col-md-4 col-sm-6 finance">
                    <div class="course-item">
                        <div class="course-thumb set-bg" data-setbg="img/courses/boot.jpg">
                            <div class="price">Free</div>
                        </div>
                        <div class="course-info">
                            <div class="course-text">
                                <h5 style="font-family: 'Nunito', sans-serif;"> Bootstrap Tutorial</h5>
                                <!--p style="font-family: 'Nunito', sans-serif;">Lorem ipsum dolor sit amet, consectetur</p-->
                                <div class="students"></div>
                            </div>
                            <div class="course-author">
                        
                                <p>SoftNotch<span> Product</span></p>
                            </div>
                        </div>
                    </div>
                </div>


                        <div class="mix col-lg-3 col-md-4 col-sm-6 design">
                    <div class="course-item">
                        <div class="course-thumb set-bg" data-setbg="img/courses/python.jpg">
                            <div class="price">Free</div>
                        </div>
                        <div class="course-info">
                            <div class="course-text">
                                <h5 style="font-family: 'Nunito', sans-serif;">Python Basics</h5>
                                <!--p style="font-family: 'Nunito', sans-serif;">Lorem ipsum dolor sit amet, consectetur</p-->
                                <div class="students"></div>
                            </div>
                            <div class="course-author">
                        
                                <p>SoftNotch<span> Product</span></p>
                            </div>
                        </div>
                    </div>
                </div>

                           <div class="mix col-lg-3 col-md-4 col-sm-6 photo">
                    <div class="course-item">
                        <div class="course-thumb set-bg" data-setbg="img/courses/apache.png">
                            <div class="price">Free</div>
                        </div>
                        <div class="course-info">
                            <div class="course-text">
                                <h5 style="font-family: 'Nunito', sans-serif;">Introduction to Ionic </h5>
                                <p style="font-family: 'Nunito', sans-serif;">Coming Soon</p>
                                <div class="students"></div>
                            </div>
                            <div class="course-author">
                        
                                <p>SoftNotch<span> Product</span></p>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- course section end -->


    <!-- signup section -->
    <section class="signup-section spad" id="register">
        <div class="signup-bg set-bg" data-setbg="img/signup-bg.jpg" ></div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6">
                    <div class="signup-warp">
                        <div class="section-title text-white text-left">
                            <h2 style="font-family: 'Nunito', sans-serif;">Sign up to become a teacher</h2>
                            <p style="font-family: 'Nunito', sans-serif;">Join Soft Learn Today to add to our courses to day.</p>
                        </div>
                        <!-- signup form -->
                        <form class="signup-form" action="index.php" method="post"  enctype="multipart/form-data" >
                            <p style="color:red;"><?php echo $update?></p>
                            <input type="text" placeholder="Your Name" name="name">
                            <input type="text" placeholder="Your E-mail" name="email">
                            <input type="text" placeholder="Your Phone" name="phone">
                            <input type="text" placeholder="Account Number" name="account">
                            <label for="v-upload"  style="background-color:rgba(145,216,247,1);" class="file-up-btn">Upload ID Card </label>
                            <input type="file" id="v-upload" name="file">
                            <button class="site-btn" name="register" type="submit">Request Verification</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- signup section end -->


    <!-- banner section -->
    <section class="banner-section spad">
        <div class="container">
            <div class="section-title mb-0 pb-2">
                <h2>Join Our Community Now!</h2>
                <p>Join Wakocoding today to either learn or teach today !!!.</p>
            </div>
            <div class="text-center pt-5">
                <a href="register.php" style="background-color:rgba(145,216,247,1);" class="site-btn">Register Now</a>
            </div>
        </div>
    </section>
    <!-- banner section end -->


    <!-- footer section -->
    <footer class="footer-section spad pb-0">
        <div class="footer-bottom">
            <div class="footer-warp">
                <ul class="footer-menu">
                    <li><a href="#">Terms & Conditions</a></li>
                    <li><a href="#">Register</a></li>
                    <li><a href="#">Privacy</a></li>
                </ul>
                <div class="copyright"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!--a href="#">Backend By : Muritala David</a-->


        </div>
    </footer> 
    <!-- footer section end -->
    </div>
<script type="text/javascript">
    var TxtRotate = function(el, toRotate, period) {
  this.toRotate = toRotate;
  this.el = el;
  this.loopNum = 0;
  this.period = parseInt(period, 10) || 2000;
  this.txt = '';
  this.tick();
  this.isDeleting = false;
};

TxtRotate.prototype.tick = function() {
  var i = this.loopNum % this.toRotate.length;
  var fullTxt = this.toRotate[i];

  if (this.isDeleting) {
    this.txt = fullTxt.substring(0, this.txt.length - 1);
  } else {
    this.txt = fullTxt.substring(0, this.txt.length + 1);
  }

  this.el.innerHTML = '<span class="wrap">'+this.txt+'</span>';

  var that = this;
  var delta = 300 - Math.random() * 100;

  if (this.isDeleting) { delta /= 2; }

  if (!this.isDeleting && this.txt === fullTxt) {
    delta = this.period;
    this.isDeleting = true;
  } else if (this.isDeleting && this.txt === '') {
    this.isDeleting = false;
    this.loopNum++;
    delta = 500;
  }

  setTimeout(function() {
    that.tick();
  }, delta);
};

window.onload = function() {
  var elements = document.getElementsByClassName('txt-rotate');
  for (var i=0; i<elements.length; i++) {
    var toRotate = elements[i].getAttribute('data-rotate');
    var period = elements[i].getAttribute('data-period');
    if (toRotate) {
      new TxtRotate(elements[i], JSON.parse(toRotate), period);
    }
  }
  // INJECT CSS
  var css = document.createElement("style");
  css.type = "text/css";
  css.innerHTML = ".txt-rotate > .wrap { border-right: 0.08em solid #666 }";
  document.body.appendChild(css);
};
</script>

    <!--====== Javascripts & Jquery ======-->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/mixitup.min.js"></script>
    <script src="js/circle-progress.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
</html>