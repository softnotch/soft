 <?php
require 'fetch.php';
if ($_COOKIE['pass']  == null) {
header('location:login.php');
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Journey | Home</title>
    <meta charset="UTF-8">
    <meta name="description" content="WebUni Education Template">
    <meta name="keywords" content="webuni, education, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Favicon -->   
    <link href="img/favicon.ico" rel="shortcut icon"/>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,500,500i,600,600i,700,700i,800,800i" rel="stylesheet">
    <!---Font Awesome--->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" type="text/css">


    <link rel="stylesheet" href="http://localhost/learn/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="http://localhost/learn/css/font-awesome.min.css"/>
    <link rel="stylesheet" href="http://localhost/learn/css/owl.carousel.css"/>
    <link rel="stylesheet" href="http://localhost/learn/css/style.css"/>


    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body>
        <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>
          <?php foreach($posts as $post): ?>

<?php
if ($post['user'] == null) {
header('location:login.php');
}
?>
  <header class="header-section" style="position: fixed; top:0rem; width: 100%; z-index: 10000; background: white; height: 26%;">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3">
                    <div class="site-logo">
                        <img src="img/wakocoding.png" alt="">
                    </div>
                    <div class="nav-switch">
                        <i class="fa fa-bars"></i>
                    </div>
                </div>
                <div class="col-lg-9 col-md-9">
                    <a href="#" class="site-btn header-btn"><?php echo $post['user']; ?></a>
                    <nav class="main-menu" style="display: block;">
                        <ul>
                            <li><a href="index.php" style="color: black;">Home</a></li>
                            <li><a href="http://localhost/learn/courses.html" style="color: black;">Tutorials/Courses</a></li>
                            <li><a href="account.php" style="color: black;">Account</a></li>
                             <li><a href="contact.php" style="color: black;">Contact</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>

    </header>
    <?php endforeach; ?>
    <!-- categories section -->

    <section class="categories-section spad">
        <div class="container">
            <br>
            <br>
            <div class="section-title">
                <h3>Our Course Categories</h3>
            </div>
            <div class="row">
                <!-- categorie -->
                <div class="col-lg-4 col-md-6">
                    <div class="categorie-item">
                               <div class="ci-thumb set-bg" style="background:  #ff6b6b; ;">
 <div class="price" style="background:  #ff6b6b; ; width:6rem; padding: 0.5rem 0.5rem 0.5rem 0.5rem; color: white; box-shadow: 0 1rem 1rem 1rem rgba(0, 0, 0, 0.1); font-family: 'poppins', sans-serif; ">NGN 8000</div>
                        </div>
                     
                        <div class="ci-text">
                            <h5>Digital Marketing</h5>
                            <p>Session by Micheal King</p>
                            <span>5 Courses</span>
                            <br>
                            <br>
                              <?php include 'valid/digital.php';?>         

                        </div>
                    </div>
                </div>

                        <div class="col-lg-4 col-md-6">
                    <div class="categorie-item">
                        <div class="ci-thumb set-bg" style="background: #1dd1a1;">
                                            <div class="price" style="background: #1dd1a1; width:6rem; padding: 0.5rem 0.5rem 0.5rem 0.5rem; color: white; box-shadow: 0 1rem 1rem 1rem rgba(0, 0, 0, 0.1); font-family: 'poppins', sans-serif; ">NGN 2000</div>
                        </div>
                        <div class="ci-text">
                            <h5>Git Tutorial</h5>
                            <p>Session by Famous</p>
                            <span>5 Courses</span>
                               <br>
                               <br>
         <?php include 'valid/git.php';?>
                        </div>
                    </div>
                </div>
                <!-- categorie -->

                <div class="col-lg-4 col-md-6" onclick="webDesign()">
                    <div class="categorie-item">
                        <div class="ci-thumb set-bg" style="background: #5f27cd;">
                        <div class="price"  style="background:#5f27cd; width:6rem; padding: 0.5rem 0.5rem 0.5rem 0.5rem; color: white; box-shadow: 0 1rem 1rem 1rem rgba(0, 0, 0, 0.1); font-family: 'poppins', sans-serif; ">NGN 5000</div>                  
                        </div>
                        <div class="ci-text">
                            <h5>Introduction To Web Design</h5>
                            <p>Session By Kelvin</p>
                            <span>70 Courses</span>
                               <br>
                               <br>
                                     <?php include 'valid/webdesign.php';?>
                        </div>
                    </div>
                </div>
    
                <!-- categorie -->
                <div class="col-lg-4 col-md-6">
                    <div class="categorie-item">
                        <div class="ci-thumb set-bg"style="background: #576574;" >
                        <div class="price" style="background:#576574; width:6rem; padding: 0.5rem 0.5rem 0.5rem 0.5rem; color: white; box-shadow: 0 1rem 1rem 1rem rgba(0, 0, 0, 0.1); font-family: 'poppins', sans-serif; ">NGN 6000</div>                  
                        </div>
                        <div class="ci-text">
                            <h5>Hybrid App Development</h5>
                            <p>Session by Famous</p>
                            <span>55 Courses</span>
                               <br>
                       <br>
                       <?php require 'valid/hybrid.php'; ?>
                        </div>
                    </div>
                </div>
                    <div class="col-lg-4 col-md-6">
                    <div class="categorie-item">
                        <div class="ci-thumb set-bg" style="background: #ff7675;">
                                            <div class="price" style="background:#ff7675; width:6rem; padding: 0.5rem 0.5rem 0.5rem 0.5rem; color: white; box-shadow: 0 1rem 1rem 1rem rgba(0, 0, 0, 0.1); font-family: 'poppins', sans-serif; " >NGN 3000</div>
                        </div>
                        <div class="ci-text">
                            <h5>UI & UX Design</h5>
                            <p>Session by Melody</p>
                            <span>5 Courses</span>
                               <br>
                        <br>
                        <?php require 'valid/uiandux.php' ?>
                        </div>
                    </div>
                </div>
                <!-- categorie -->
                <div class="col-lg-4 col-md-6">
                    <div class="categorie-item">
                        <div class="ci-thumb set-bg" style="background: #0984e3;">
                        <div class="price"   style="background:#0984e3; width:6rem; padding: 0.5rem 0.5rem 0.5rem 0.5rem; color: white; box-shadow: 0 1rem 1rem 1rem rgba(0, 0, 0, 0.1); font-family: 'poppins', sans-serif; ">NGN 8500</div>                  
                        </div>
                        <div class="ci-text">
                            <h5>Introduction to Python</h5>
                            <p>Session by Muritala David</p>
                            <span>40 Courses</span>
                               <br>
                            <br>
                            <?php require 'valid/python.php'; ?>
                        </div>
                    </div>
                </div>
                <!-- categorie -->
                <div class="col-lg-4 col-md-6">
                    <div class="categorie-item">
                        <div class="ci-thumb set-bg"  style="background:#e17055;">
                        <div class="price"  style="background::#e17055; width:6rem; padding: 0.5rem 0.5rem 0.5rem 0.5rem; color: white; box-shadow: 0 1rem 1rem 1rem rgba(0, 0, 0, 0.1); font-family: 'poppins', sans-serif; ">NGN 3000</div>                  
                        </div>
                        <div class="ci-text">
                            <h5>Database Management [MySQL] </h5>
                            <p>Session by Muritala David</p>
                            <span>20 Courses</span>
                               <br>
                            <br>
                            <?php require 'valid/mysql.php'; ?>
                        </div>
                    </div>
                </div>
                <!-- categorie -->
                <div class="col-lg-4 col-md-6">
                    <div class="categorie-item">
                        <div class="ci-thumb set-bg"   style="background:#fdcb6e;">
                        <div class="price"  style="background:#fdcb6e; width:6rem; padding: 0.5rem 0.5rem 0.5rem 0.5rem; color: white; box-shadow: 0 1rem 1rem 1rem rgba(0, 0, 0, 0.1); font-family: 'poppins', sans-serif; ">NGN 4000</div>                  
                        </div>
                        <div class="ci-text">
                            <h5>Introduction To JavaScript</h5>
                            <p>Session by Kelvin</p>
                            <span>25 Courses</span>
                               <br>
                            <br>
                            <?php require 'valid/javascript.php';?>
                        </div>
                    </div>
                </div>
                        <div class="col-lg-4 col-md-6">
                    <div class="categorie-item">
                        <div class="ci-thumb set-bg" style="background: #00b894;">
                                            <div class="price" style="background:#00b894; width:6rem; padding: 0.5rem 0.5rem 0.5rem 0.5rem; color: white; box-shadow: 0 1rem 1rem 1rem rgba(0, 0, 0, 0.1); font-family: 'poppins', sans-serif; ">NGN 5500</div>
                        </div>
                        <div class="ci-text">
                            <h5>Introduction To Java</h5>
                            <p>Session by John</p>
                            <span>25 Courses</span>
                               <br>
                            <br>
                            <?php require 'valid/java.php'?>
                        </div>
                    </div>
                </div>

                      <div class="col-lg-4 col-md-6">
                    <div class="categorie-item">
                        <div class="ci-thumb set-bg" style="background: #6c5ce7;">
                                            <div class="price" style="background: #6c5ce7; width:6rem; padding: 0.5rem 0.5rem 0.5rem 0.5rem; color: white; box-shadow: 0 1rem 1rem 1rem rgba(0, 0, 0, 0.1); font-family: 'poppins', sans-serif; ">NGN 1800</div>
                        </div>
                        <div class="ci-text">
                            <h5>Introduction To Clang</h5>
                            <p>Session by John</p>
                            <span>25 Courses</span>
                               <br>
                            <br>
                            <?php require 'valid/clang.php'?>
                        </div>
                    </div>
                </div>

                        <a href="" style="text-align: center;">MORE</a>
            </div>
        </div>


    </section>
    <!-- categories section end -->
    <script type="text/javascript">
        function webDesign(){
            window.location.href='courses/html.php';
        }
    </script>
    <!--====== Javascripts & Jquery ======-->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/mixitup.min.js"></script>
    <script src="js/circle-progress.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>