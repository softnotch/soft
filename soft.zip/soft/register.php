 <?php

require 'conn.php';
    
session_start();

if (isset($_POST['register'])) {

$user = $_POST['user'];
$email  = $_POST['email'];
$pass = $_POST['pass'];

$sql = "INSERT INTO users (user, email, pass) VALUES ('$user', '$email', '$pass')";

$result = mysqli_query($conn, $sql);

if ($result) {
  header('location:login.php');
}
else{
    echo "error";
} 

//echo $_SESSION['user'];
}
?>

<!DOCTYPE html>
<html>
<head>
        <title>Soft Learn | Login</title>
    <meta charset="UTF-8">
    <meta name="description" content="WebUni Education Template">
    <meta name="keywords" content="webuni, education, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Favicon -->   
    <link href="img/favicon.ico" rel="shortcut icon"/>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,500,500i,600,600i,700,700i,800,800i" rel="stylesheet">
    <!---Font Awesome--->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" type="text/css">


    <link rel="stylesheet" href="css/bootstrap.min.css"/>
    <link rel="stylesheet" href="css/font-awesome.min.css"/>
    <link rel="stylesheet" href="css/owl.carousel.css"/>
    <link rel="stylesheet" href="css/style.css"/>


    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body>
<div >
        <!-- signup section -->
    <section class="signup-section spad" id="register">
        <div class="signup-bg set-bg" data-setbg="img/signup-bg.jpg"></div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6">
                    <div class="signup-warp">
                        <div class="section-title text-white text-left">
                            <h2 style="font-family: 'Nunito', sans-serif; width: 100%;">Login to your account</h2>
                            <p style="font-family: 'Nunito', sans-serif; ">Join Soft Learn Today to add to our courses to day.</p>
                        </div>
                        <!-- signup form -->
                        <form class="signup-form" action="register.php" method="post">
                            <input type="text" placeholder="Username"   name="user" required value="<?php echo $_COOKIE['testuser']; ?>">
                            <input type="email" placeholder="Your E-mail" name="email" required value="<?php echo $_COOKIE['testemail']; ?>">
                            <input type="password" placeholder="Password" name="pass" required>

                            <button class="site-btn" style="background: black;" name="register" type="submit">Register</button>
                        </form>
                        <br>
                               <a href="register.php" style="color: white; font-family: 'Nunito', sans-serif; width: 100%;"> Have an account ? Login</a>
                    </div>
                </div>  
                   </div>
</div>
            </div>
        </div>

    </section>
    <!-- signup section end -->


</div>
</body>
</html>