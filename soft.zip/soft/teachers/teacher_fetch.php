<?php
require 'conn.php';

$query  = "SELECT  id,name, email FROM tutors WHERE secret = '{$_COOKIE['secret']}' ";

$result   = mysqli_query($conn, $query);

$posts =  mysqli_fetch_all($result, MYSQLI_ASSOC);

mysqli_free_result($result);


?>