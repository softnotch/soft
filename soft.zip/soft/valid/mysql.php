<?php
require 'conn.php';

$sql = "SELECT state FROM payment WHERE pass = '{$_COOKIE['pass']}' AND product = 'mysql' ";

$result = mysqli_query($conn, $sql);

$posts = mysqli_fetch_all($result, MYSQLI_ASSOC);

mysqli_free_result($result);

mysqli_close($conn);
?>


<?php foreach($posts as $post): ?>
<?php if($post['state'] == "paid"){
        $gen = "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $res = substr(str_shuffle($gen), 0,12);
        echo "<a href='http://localhost/learn/courses/mysql.php?code=$res' class='btn btn-primary'>Watch</a>";
}else{
    echo "<a href='https://paystack.com/pay/7wl0hd844x'  class='btn btn-danger'>Buy</a>";
}
?>
<?php endforeach; ?>